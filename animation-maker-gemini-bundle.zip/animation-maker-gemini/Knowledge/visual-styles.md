# Visual Styles

## Low-Poly 3D Story World
Use faceted geometry, deliberate palettes, clear silhouettes, readable depth, stylized props, and expressive characters. Compose for a narrow vertical frame. Use purposeful camera pushes, pans, tilts, parallax, and motivated cuts—not random motion.

## Fast 2D Motion
Use expressive poses, anticipation, squash-and-stretch where appropriate, speed lines, kinetic typography, impact frames, graphic wipes, and energetic transitions. Vary shot scale and composition; do not rely on text effects alone.

## Hybrid 2D + Low-Poly 3D
Keep 2D character proportions and outlines consistent against the 3D environment. Use perspective, shadows, contact points, and lighting to ground characters. Use depth layers and parallax without clutter.

## Atmospheric Horror
Build suspense through framing, negative space, selective lighting, environmental movement, sound, and controlled reveals. Slow pacing must still develop tension through meaningful visual or audio changes. Do not rely on jump scares alone. Keep story beats and subtitles understandable.
