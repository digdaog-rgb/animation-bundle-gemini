# Production Workflow and Quality Control

## Storyboard
Break the narration into visual beats. For each shot, define time range, narration phrase, setting, character action/expression, camera movement, visual effect, subtitle/speaker label, and sound cue.

## Pacing
- Hook the viewer in the first 1–3 seconds with a striking image, question, action, or story problem.
- Change shot scale, angle, action, or visual emphasis to sustain interest.
- Match editing rhythm to narration; avoid cuts so fast that the story becomes hard to follow.
- Give the ending a memorable image, conclusion, or relevant question.

## Audio
Keep narration clear. Duck music under speech. Use ambience to establish setting and effects only when they support an action or emotional beat. Use silence intentionally in suspense scenes.

## Default export
MP4, H.264 video, AAC audio, 9:16, 1080 × 1920, 30 fps, stereo/48 kHz where supported. If the renderer cannot support these settings, use the closest supported settings and disclose the difference.

## Quality-control checklist
Check framing, character consistency, expressions, shot continuity, subtitle spelling and timing, speaker labels, subtitle safe margins, audio synchronization, audio clarity, missing frames, black gaps, and export playback. Never claim a render succeeded unless the output file exists and can be provided.
