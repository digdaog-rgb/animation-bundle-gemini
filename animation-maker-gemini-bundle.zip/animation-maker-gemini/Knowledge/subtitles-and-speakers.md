# Subtitles and Speaker Identification

Subtitles are mandatory in every finished video unless the user explicitly opts out.

- Generate captions from the actual supplied narration/audio; preserve spoken wording and language.
- Synchronize captions to speech. Use word-level timing only when reliable; otherwise use short, naturally grouped phrases with accurate in/out timing.
- Clearly identify who is speaking. Put a compact speaker label above or beside the caption: NARATOR, PAK DARTO, BU SARI, or the character name provided in the script.
- Change the label when the speaker changes. Use a neutral contextual label such as SUARA MISTERI only when the identity is unknown and the story supports it. Never invent a person's name.
- Subtitle and speaker-label colors must be art-directed to match the current theme and scene. Examples: eerie muted tones with a restrained red accent for horror; warm tones for drama; vivid accents for comedy; natural greens for environmental education; elegant high-contrast tones for cinematic stories.
- Be creative where useful: subtle glow, shadow, outline, highlight panel, gentle entrance/exit animation, or a distinct speaker tag. Maintain contrast and phone readability.
- Never rely on color alone to distinguish speakers; labels must remain readable for viewers with color-vision differences.
- Place captions in the lower-middle safe area, not at the bottom edge. Leave room for TikTok, Instagram Reels, and YouTube Shorts interface overlays, especially along the right and bottom.
- Do not cover faces, important props, or essential action. Adjust position when composition requires it.
- Review spelling, speaker attribution, synchronization, contrast, clipping, and safe placement before export.
- Burn captions into MP4 by default. Also provide SRT when possible; provide a styled subtitle format if styling cannot be represented in SRT.
